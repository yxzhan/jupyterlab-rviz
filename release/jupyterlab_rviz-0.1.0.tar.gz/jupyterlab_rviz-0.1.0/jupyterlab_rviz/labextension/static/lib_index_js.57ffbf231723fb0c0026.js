"use strict";
(self["webpackChunkjupyterlab_rviz"] = self["webpackChunkjupyterlab_rviz"] || []).push([["lib_index_js"],{

/***/ "./lib/RVIZ.js":
/*!*********************!*\
  !*** ./lib/RVIZ.js ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_0__);

class RVIZWidget extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__.Widget {
    /**
    * Construct a new APOD widget.
    */
    constructor() {
        super();
        this.addClass('my-apodWidget');
        this.iframe = document.createElement('iframe');
        // this.iframe.src = `http://${location.hostname}:8001/rvizweb/www/index.html`;
        this.iframe.src = `http://127.0.0.1:5501/examples/urdf.html`;
        this.iframe.style.width = '100%';
        this.iframe.style.height = '100%';
        this.node.appendChild(this.iframe);
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RVIZWidget);


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/application */ "webpack/sharing/consume/default/@jupyterlab/application");
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/launcher */ "webpack/sharing/consume/default/@jupyterlab/launcher");
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _RVIZ__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./RVIZ */ "./lib/RVIZ.js");




/**
 * Initialization data for the jupyterlab_rviz extension.
 */
function activate(app, palette, launcher, restorer) {
    console.log('JupyterLab extension jupyterlab_rviz is activated!');
    // Declare a widget variable
    let widget;
    // Add an application command
    const command = 'rviz:open';
    app.commands.addCommand(command, {
        label: 'Open Rvizweb',
        execute: () => {
            if (!widget || widget.isDisposed) {
                const content = new _RVIZ__WEBPACK_IMPORTED_MODULE_3__["default"]();
                widget = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__.MainAreaWidget({ content });
                widget.id = 'rviz-jupyterlab';
                widget.title.label = 'Rvizweb';
                widget.title.closable = true;
            }
            if (!tracker.has(widget)) {
                // Track the state of the widget for later restoration
                tracker.add(widget);
            }
            if (!widget.isAttached) {
                // Attach the widget to the main work area if it's not there
                app.shell.add(widget, 'main');
            }
            // Activate the widget
            app.shell.activateById(widget.id);
        }
    });
    // Add the command to the palette.
    palette.addItem({ command, category: 'Tutorial' });
    if (launcher) {
        launcher.add({
            command,
            category: 'Robotics',
            rank: 1,
        });
    }
    // Track and restore the widget state
    let tracker = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__.WidgetTracker({
        namespace: 'rviz'
    });
    if (restorer) {
        restorer.restore(tracker, {
            command,
            name: () => 'rviz'
        });
    }
}
;
const plugin = {
    id: 'jupyterlab_rviz',
    autoStart: true,
    requires: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__.ICommandPalette],
    optional: [_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_1__.ILauncher, _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__.ILayoutRestorer],
    activate: activate
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.57ffbf231723fb0c0026.js.map