"use strict";
(self["webpackChunkjupyterlab_rviz"] = self["webpackChunkjupyterlab_rviz"] || []).push([["lib_index_js"],{

/***/ "./style/robot.svg":
/*!*************************!*\
  !*** ./style/robot.svg ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\r\n<!-- Uploaded to: SVG Repo, www.svgrepo.com, Generator: SVG Repo Mixer Tools -->\r\n<svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" \r\n\t viewBox=\"0 0 512 512\" xml:space=\"preserve\">\r\n<path style=\"fill:#2BA5F7;\" d=\"M256.002,90.32c-4.725,0-8.553-3.829-8.553-8.553V23.369c0-4.723,3.828-8.553,8.553-8.553\r\n\tc4.725,0,8.553,3.829,8.553,8.553v58.398C264.555,86.49,260.727,90.32,256.002,90.32z\"/>\r\n<rect x=\"191.825\" y=\"208.645\" style=\"fill:#E09B2D;\" width=\"128.351\" height=\"34.782\"/>\r\n<path style=\"fill:#F95428;\" d=\"M364.126,81.047v136.721h-43.951H191.825h-43.951V81.047c0-15.977,12.955-28.932,28.932-28.932h79.2\r\n\th79.189C351.182,52.116,364.126,65.071,364.126,81.047z\"/>\r\n<path style=\"fill:#E54728;\" d=\"M196.192,52.116h-19.387c-15.977,0-28.932,12.955-28.932,28.932v136.721h19.387V81.047\r\n\tC167.261,65.071,180.216,52.116,196.192,52.116z\"/>\r\n<g>\r\n\t<rect x=\"171.606\" y=\"363.784\" style=\"fill:#F7B239;\" width=\"33.413\" height=\"121.303\"/>\r\n\t<rect x=\"306.992\" y=\"363.784\" style=\"fill:#F7B239;\" width=\"33.402\" height=\"121.303\"/>\r\n</g>\r\n<path style=\"fill:#E09B2D;\" d=\"M306.992,364.924v42.103h33.402v-42.103H306.992z M171.606,407.027h33.413v-42.103h-33.413V407.027z\"\r\n\t/>\r\n<g>\r\n\t<rect x=\"348.799\" y=\"264.091\" style=\"fill:#F7B239;\" width=\"62.299\" height=\"35.17\"/>\r\n\t<rect x=\"100.468\" y=\"264.091\" style=\"fill:#F7B239;\" width=\"63.166\" height=\"35.17\"/>\r\n\t<path style=\"fill:#F7B239;\" d=\"M203.251,108.576c16.513,0,29.89,13.388,29.89,29.89c0,16.513-13.377,29.89-29.89,29.89\r\n\t\tc-16.501,0-29.878-13.377-29.878-29.89C173.373,121.964,186.75,108.576,203.251,108.576z\"/>\r\n\t<path style=\"fill:#F7B239;\" d=\"M308.749,108.576c16.501,0,29.89,13.388,29.89,29.89c0,16.513-13.388,29.89-29.89,29.89\r\n\t\tc-16.513,0-29.89-13.377-29.89-29.89C278.859,121.964,292.236,108.576,308.749,108.576z\"/>\r\n</g>\r\n<g>\r\n\t<polygon style=\"fill:#F95428;\" points=\"224.36,471.562 224.36,512 152.265,512 152.265,471.562 171.606,471.562 205.019,471.562 \t\r\n\t\t\"/>\r\n\t<polygon style=\"fill:#F95428;\" points=\"359.735,471.562 359.735,512 287.651,512 287.651,471.562 306.992,471.562 340.394,471.562 \r\n\t\t\t\"/>\r\n\t<path style=\"fill:#F95428;\" d=\"M416.253,269.611v140.416h-31.885V299.261v-35.17v-26.366l0,0\r\n\t\tC401.978,237.725,416.253,252.001,416.253,269.611z\"/>\r\n\t<path style=\"fill:#F95428;\" d=\"M127.632,299.261v110.766H95.747V269.611c0-17.61,14.275-31.885,31.885-31.885l0,0v26.366V299.261z\"\r\n\t\t/>\r\n</g>\r\n<path style=\"fill:#2BA5F7;\" d=\"M364.126,299.261v78.048h-23.731v-0.011h-33.402v0.011H205.019v-0.011h-33.413v0.011h-23.731v-78.048\r\n\tv-35.17v-26.366h43.951h128.351h43.951v26.366L364.126,299.261L364.126,299.261z\"/>\r\n<rect x=\"147.874\" y=\"237.725\" style=\"fill:#2197D8;\" width=\"38.043\" height=\"139.572\"/>\r\n<g>\r\n\t<path style=\"fill:#4D4D4D;\" d=\"M241.698,138.467c0-21.196-17.245-38.441-38.441-38.441c-21.198,0-38.442,17.245-38.442,38.441\r\n\t\ts17.245,38.441,38.442,38.441C224.453,176.908,241.698,159.663,241.698,138.467z M181.92,138.467\r\n\t\tc0-11.764,9.572-21.336,21.337-21.336s21.336,9.571,21.336,21.336c0,11.764-9.571,21.336-21.336,21.336\r\n\t\tS181.92,150.231,181.92,138.467z\"/>\r\n\t<path style=\"fill:#4D4D4D;\" d=\"M308.748,176.908c21.196,0,38.441-17.245,38.441-38.441s-17.245-38.441-38.441-38.441\r\n\t\tc-21.198,0-38.442,17.245-38.442,38.441S287.55,176.908,308.748,176.908z M308.748,117.13c11.764,0,21.335,9.571,21.335,21.336\r\n\t\ts-9.571,21.336-21.335,21.336s-21.337-9.571-21.337-21.336S296.983,117.13,308.748,117.13z\"/>\r\n\t<circle style=\"fill:#4D4D4D;\" cx=\"316.275\" cy=\"271.127\" r=\"8.553\"/>\r\n\t<circle style=\"fill:#4D4D4D;\" cx=\"195.725\" cy=\"271.127\" r=\"8.553\"/>\r\n</g>\r\n<circle style=\"fill:#F7B239;\" cx=\"256.006\" cy=\"14.816\" r=\"14.816\"/>\r\n<path style=\"fill:#E09B2D;\" d=\"M303.469,330.906h-94.937c0-11.073,3.798-21.268,10.149-29.342\r\n\tc8.701-11.039,22.181-18.132,37.325-18.132C282.223,283.432,303.469,304.689,303.469,330.906z\"/>\r\n<path style=\"fill:#F7B239;\" d=\"M294.813,330.906h-86.282c0-11.073,3.798-21.268,10.149-29.342\r\n\tc8.074-6.352,18.258-10.149,29.342-10.149C271.515,291.415,291.027,308.486,294.813,330.906z\"/>\r\n</svg>");

/***/ }),

/***/ "./lib/RVIZ.js":
/*!*********************!*\
  !*** ./lib/RVIZ.js ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_0__);

class RVIZWidget extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__.Widget {
    /**
    * Construct a new APOD widget.
    */
    constructor() {
        super();
        this.addClass('my-apodWidget');
        this.iframe = document.createElement('iframe');
        this.iframe.src = `http://${location.hostname}:8001/rvizweb/www/index.html`;
        // this.iframe.src = `http://127.0.0.1:5501/examples/urdf.html`;
        this.iframe.style.width = '100%';
        this.iframe.style.height = '100%';
        this.node.appendChild(this.iframe);
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RVIZWidget);


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/application */ "webpack/sharing/consume/default/@jupyterlab/application");
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/launcher */ "webpack/sharing/consume/default/@jupyterlab/launcher");
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _style_robot_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../style/robot.svg */ "./style/robot.svg");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _RVIZ__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./RVIZ */ "./lib/RVIZ.js");






/**
 * Initialization data for the jupyterlab_rviz extension.
 */
function activate(app, palette, launcher, restorer) {
    console.log('JupyterLab extension jupyterlab_rviz is activated!');
    // Declare a widget variable
    let widget;
    // Add an application command
    const command = 'rviz:open';
    const icon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
        name: 'launcher:rviz-icon',
        svgstr: _style_robot_svg__WEBPACK_IMPORTED_MODULE_4__["default"],
    });
    app.commands.addCommand(command, {
        caption: 'Open Rvizweb',
        label: (args) => (args['isPalette'] ? 'Open Rvizweb' : 'Rvizweb'),
        icon: (args) => (args['isPalette'] ? '' : icon),
        execute: () => {
            if (!widget || widget.isDisposed) {
                const content = new _RVIZ__WEBPACK_IMPORTED_MODULE_5__["default"]();
                widget = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_3__.MainAreaWidget({ content });
                widget.id = 'rviz-jupyterlab';
                widget.title.label = 'Rvizweb';
                widget.title.closable = true;
            }
            if (!tracker.has(widget)) {
                // Track the state of the widget for later restoration
                tracker.add(widget);
            }
            if (!widget.isAttached) {
                // Attach the widget to the main work area if it's not there
                app.shell.add(widget, 'main', { mode: 'split-right' });
            }
            // Activate the widget
            app.shell.activateById(widget.id);
        }
    });
    // Add the command to the palette.
    palette.addItem({ command, category: 'Visualization' });
    if (launcher) {
        launcher.add({
            command,
            rank: 1,
        });
    }
    // Track and restore the widget state
    let tracker = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_3__.WidgetTracker({
        namespace: 'rviz'
    });
    if (restorer) {
        restorer.restore(tracker, {
            command,
            name: () => 'rviz'
        });
    }
}
;
const plugin = {
    id: 'jupyterlab_rviz',
    autoStart: true,
    requires: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_3__.ICommandPalette],
    optional: [_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_1__.ILauncher, _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__.ILayoutRestorer],
    activate: activate
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.df562adcb2ee4201c112.js.map