"use strict";
(self["webpackChunkjupyterlab_rviz"] = self["webpackChunkjupyterlab_rviz"] || []).push([["lib_index_js"],{

/***/ "./style/Ros_logo.svg":
/*!****************************!*\
  !*** ./style/Ros_logo.svg ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n<svg\n   xmlns:dc=\"http://purl.org/dc/elements/1.1/\"\n   xmlns:cc=\"http://creativecommons.org/ns#\"\n   xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"\n   xmlns:svg=\"http://www.w3.org/2000/svg\"\n   xmlns=\"http://www.w3.org/2000/svg\"\n   xmlns:sodipodi=\"http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd\"\n   xmlns:inkscape=\"http://www.inkscape.org/namespaces/inkscape\"\n   id=\"svg2\"\n   version=\"1.1\"\n   viewBox=\"0 0 385.99219 102.04687\"\n   height=\"102.04688pt\"\n   width=\"385.99219pt\"\n   sodipodi:docname=\"Ros_logo.svg\"\n   inkscape:export-filename=\"/home/mguenther/Downloads/ros-press-kit/1280px-Ros_logo.svg.png\"\n   inkscape:export-xdpi=\"238.75999\"\n   inkscape:export-ydpi=\"238.75999\"\n   inkscape:version=\"0.92.5 (2060ec1f9f, 2020-04-08)\">\n  <sodipodi:namedview\n     pagecolor=\"#ffffff\"\n     bordercolor=\"#666666\"\n     borderopacity=\"1\"\n     objecttolerance=\"10\"\n     gridtolerance=\"10\"\n     guidetolerance=\"10\"\n     inkscape:pageopacity=\"0\"\n     inkscape:pageshadow=\"2\"\n     inkscape:window-width=\"2560\"\n     inkscape:window-height=\"1391\"\n     id=\"namedview33\"\n     showgrid=\"false\"\n     fit-margin-top=\"0\"\n     fit-margin-left=\"0\"\n     fit-margin-right=\"0\"\n     fit-margin-bottom=\"0\"\n     inkscape:zoom=\"3.1550388\"\n     inkscape:cx=\"232.61011\"\n     inkscape:cy=\"102.64938\"\n     inkscape:window-x=\"0\"\n     inkscape:window-y=\"25\"\n     inkscape:window-maximized=\"1\"\n     inkscape:current-layer=\"svg2\" />\n  <metadata\n     id=\"metadata58\">\n    <rdf:RDF>\n      <cc:Work\n         rdf:about=\"\">\n        <dc:format>image/svg+xml</dc:format>\n        <dc:type\n           rdf:resource=\"http://purl.org/dc/dcmitype/StillImage\" />\n        <dc:title></dc:title>\n      </cc:Work>\n    </rdf:RDF>\n  </metadata>\n  <defs\n     id=\"defs4\">\n    <clipPath\n       id=\"clip1\">\n      <path\n         id=\"path7\"\n         d=\"M 0.0585938,2 H 22 V 25 H 0.0585938 Z m 0,0\"\n         inkscape:connector-curvature=\"0\" />\n    </clipPath>\n    <clipPath\n       id=\"clip2\">\n      <path\n         id=\"path10\"\n         d=\"M 0.0585938,40 H 22 V 64 H 0.0585938 Z m 0,0\"\n         inkscape:connector-curvature=\"0\" />\n    </clipPath>\n    <clipPath\n       id=\"clip3\">\n      <path\n         id=\"path13\"\n         d=\"M 0.0585938,79 H 22 v 23 H 0.0585938 Z m 0,0\"\n         inkscape:connector-curvature=\"0\" />\n    </clipPath>\n    <clipPath\n       id=\"clip4\">\n      <path\n         id=\"path16\"\n         d=\"m 220,0.894531 h 82 V 102.94141 h -82 z m 0,0\"\n         inkscape:connector-curvature=\"0\" />\n    </clipPath>\n    <clipPath\n       id=\"clip5\">\n      <path\n         id=\"path19\"\n         d=\"m 316,0.894531 h 70.05078 V 102.94141 H 316 Z m 0,0\"\n         inkscape:connector-curvature=\"0\" />\n    </clipPath>\n  </defs>\n  <g\n     id=\"surface839\"\n     transform=\"translate(-0.0585938,-0.894531)\">\n    <g\n       id=\"g22\"\n       clip-path=\"url(#clip1)\"\n       style=\"clip-rule:nonzero\">\n      <path\n         id=\"path24\"\n         d=\"m 21.839844,13.492188 c 0,6.230468 -4.890625,11.285156 -10.917969,11.285156 C 4.890625,24.777344 0,19.722656 0,13.492188 0,7.257812 4.890625,2.207031 10.921875,2.207031 c 6.027344,0 10.917969,5.050781 10.917969,11.285157\"\n         style=\"fill:#212e4a;fill-opacity:1;fill-rule:nonzero;stroke:none\"\n         inkscape:connector-curvature=\"0\" />\n    </g>\n    <g\n       id=\"g26\"\n       clip-path=\"url(#clip2)\"\n       style=\"clip-rule:nonzero\">\n      <path\n         id=\"path28\"\n         d=\"m 21.839844,51.949219 c 0,6.230469 -4.890625,11.285156 -10.917969,11.285156 C 4.890625,63.234375 0,58.179688 0,51.949219 0,45.714844 4.890625,40.664062 10.921875,40.664062 c 6.027344,0 10.917969,5.050782 10.917969,11.285157\"\n         style=\"fill:#212e4a;fill-opacity:1;fill-rule:nonzero;stroke:none\"\n         inkscape:connector-curvature=\"0\" />\n    </g>\n    <g\n       id=\"g30\"\n       clip-path=\"url(#clip3)\"\n       style=\"clip-rule:nonzero\">\n      <path\n         id=\"path32\"\n         d=\"m 21.839844,90.40625 c 0,6.230469 -4.890625,11.28516 -10.917969,11.28516 C 4.890625,101.69141 0,96.636719 0,90.40625 0,84.175781 4.890625,79.121094 10.921875,79.121094 c 6.027344,0 10.917969,5.054687 10.917969,11.285156\"\n         style=\"fill:#212e4a;fill-opacity:1;fill-rule:nonzero;stroke:none\"\n         inkscape:connector-curvature=\"0\" />\n    </g>\n    <path\n       id=\"path34\"\n       d=\"m 59.945312,51.949219 c 0,6.230469 -4.886718,11.285156 -10.917968,11.285156 -6.03125,0 -10.921875,-5.054687 -10.921875,-11.285156 0,-6.234375 4.890625,-11.285157 10.921875,-11.285157 6.03125,0 10.917968,5.050782 10.917968,11.285157\"\n       style=\"fill:#212e4a;fill-opacity:1;fill-rule:nonzero;stroke:none\"\n       inkscape:connector-curvature=\"0\" />\n    <path\n       id=\"path36\"\n       d=\"m 59.945312,13.492188 c 0,6.230468 -4.886718,11.285156 -10.917968,11.285156 -6.03125,0 -10.921875,-5.054688 -10.921875,-11.285156 0,-6.234376 4.890625,-11.285157 10.921875,-11.285157 6.03125,0 10.917968,5.050781 10.917968,11.285157\"\n       style=\"fill:#212e4a;fill-opacity:1;fill-rule:nonzero;stroke:none\"\n       inkscape:connector-curvature=\"0\" />\n    <path\n       id=\"path38\"\n       d=\"m 98.054688,51.949219 c 0,6.230469 -4.890626,11.285156 -10.921876,11.285156 -6.03125,0 -10.917968,-5.054687 -10.917968,-11.285156 0,-6.234375 4.886718,-11.285157 10.917968,-11.285157 6.03125,0 10.921876,5.050782 10.921876,11.285157\"\n       style=\"fill:#212e4a;fill-opacity:1;fill-rule:nonzero;stroke:none\"\n       inkscape:connector-curvature=\"0\" />\n    <path\n       id=\"path40\"\n       d=\"m 98.054688,13.492188 c 0,6.230468 -4.890626,11.285156 -10.921876,11.285156 -6.03125,0 -10.917968,-5.054688 -10.917968,-11.285156 0,-6.234376 4.886718,-11.285157 10.917968,-11.285157 6.03125,0 10.921876,5.050781 10.921876,11.285157\"\n       style=\"fill:#212e4a;fill-opacity:1;fill-rule:nonzero;stroke:none\"\n       inkscape:connector-curvature=\"0\" />\n    <path\n       id=\"path42\"\n       d=\"m 98.054688,90.40625 c 0,6.230469 -4.890626,11.28516 -10.921876,11.28516 -6.03125,0 -10.917968,-5.054691 -10.917968,-11.28516 0,-6.230469 4.886718,-11.285156 10.917968,-11.285156 6.03125,0 10.921876,5.054687 10.921876,11.285156\"\n       style=\"fill:#212e4a;fill-opacity:1;fill-rule:nonzero;stroke:none\"\n       inkscape:connector-curvature=\"0\" />\n    <path\n       id=\"path44\"\n       d=\"m 59.945312,90.40625 c 0,6.230469 -4.886718,11.28516 -10.917968,11.28516 -6.03125,0 -10.921875,-5.054691 -10.921875,-11.28516 0,-6.230469 4.890625,-11.285156 10.921875,-11.285156 6.03125,0 10.917968,5.054687 10.917968,11.285156\"\n       style=\"fill:#212e4a;fill-opacity:1;fill-rule:nonzero;stroke:none\"\n       inkscape:connector-curvature=\"0\" />\n    <path\n       id=\"path46\"\n       d=\"m 171.61328,16.453125 h -27.91797 v 31.816406 h 27.91797 c 9.57813,0 16.28125,-5.089843 16.28125,-15.835937 0,-10.324219 -6.56641,-15.980469 -16.28125,-15.980469 z M 181.32812,61 200.89453,101.44531 H 184.33984 L 165.31641,62.273438 h -21.6211 V 101.44531 H 129.60156 V 2.449219 h 42.01172 c 16.69531,0 30.78906,9.195312 30.78906,29.558593 0,15.839844 -8.07422,25.597657 -21.07422,28.992188\"\n       style=\"fill:#212e4a;fill-opacity:1;fill-rule:nonzero;stroke:none\"\n       inkscape:connector-curvature=\"0\" />\n    <g\n       id=\"g48\"\n       clip-path=\"url(#clip4)\"\n       style=\"clip-rule:nonzero\">\n      <path\n         id=\"path50\"\n         d=\"m 260.5625,15.746094 c -16.69531,0 -25.86328,14 -25.86328,36.203125 0,22.203125 9.16797,36.203125 25.86328,36.203125 16.83203,0 26,-14 26,-36.203125 0,-22.203125 -9.16797,-36.203125 -26,-36.203125 z m 0,87.253906 c -24.76563,0 -40.50391,-21.070312 -40.50391,-51.050781 0,-29.980469 15.73828,-51.054688 40.50391,-51.054688 24.90625,0 40.64062,21.074219 40.64062,51.054688 C 301.20312,81.929688 285.46875,103 260.5625,103\"\n         style=\"fill:#212e4a;fill-opacity:1;fill-rule:nonzero;stroke:none\"\n         inkscape:connector-curvature=\"0\" />\n    </g>\n    <g\n       id=\"g52\"\n       clip-path=\"url(#clip5)\"\n       style=\"clip-rule:nonzero\">\n      <path\n         id=\"path54\"\n         d=\"m 350.60937,103 c -13.96093,0 -26,-6.222656 -34.07421,-15.980469 l 10.26171,-10.324219 c 6.4336,7.214844 15.875,11.738282 24.90625,11.738282 13.41016,0 19.83985,-4.808594 19.83985,-14.425782 0,-7.636718 -5.60938,-11.453124 -21.6211,-16.402343 -20.25,-6.222657 -29.96484,-11.457031 -29.96484,-29.132813 0,-17.113281 13.95703,-27.578125 31.60938,-27.578125 13,0 22.85156,4.953125 31.33593,13.4375 l -10.125,10.605469 c -6.02343,-6.363281 -12.86328,-9.476562 -22.30468,-9.476562 -11.22266,0 -16.01172,5.65625 -16.01172,12.304687 0,6.929687 4.3789,10.324219 20.9375,15.414063 18.88281,5.941406 30.65234,12.164062 30.65234,29.839843 C 386.05078,90.839844 375.10156,103 350.60937,103\"\n         style=\"fill:#212e4a;fill-opacity:1;fill-rule:nonzero;stroke:none\"\n         inkscape:connector-curvature=\"0\" />\n    </g>\n  </g>\n</svg>\n");

/***/ }),

/***/ "./lib/iframe.js":
/*!***********************!*\
  !*** ./lib/iframe.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_0__);

class IFrameWidget extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__.Widget {
    /**
    * Construct a new IFrameWidget widget.
    */
    constructor(url) {
        super();
        // Get base URL of current notebook server
        // Construct URL of our proxied service
        this.iframe = document.createElement('iframe');
        console.log(`open url:\n${url}`);
        this.iframe.src = url;
        this.iframe.style.width = '100%';
        this.iframe.style.height = '100%';
        this.node.appendChild(this.iframe);
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (IFrameWidget);


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/application */ "webpack/sharing/consume/default/@jupyterlab/application");
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/launcher */ "webpack/sharing/consume/default/@jupyterlab/launcher");
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _iframe__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./iframe */ "./lib/iframe.js");
/* harmony import */ var _style_Ros_logo_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../style/Ros_logo.svg */ "./style/Ros_logo.svg");







// import armStr from '../style/Robot_arm_icon.svg';
const BASE_URL = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_4__.PageConfig.getBaseUrl();
/**
 * Initialization data for the jupyterlab_rviz extension.
 */
async function activate(app, palette, launcher, restorer) {
    console.log('JupyterLab extension jupyterlab_rviz is activated!');
    let response = await fetch(`${BASE_URL}proxy/8001/rvizweb/jupyter-apps/app.json`);
    if (!response.ok) {
        const data = await response.json();
        if (data.error) {
            console.log(data.error);
        }
        return;
    }
    const RvizApps = await response.json();
    for (let appConfig of RvizApps) {
        response = await fetch(`${BASE_URL}${appConfig.icon}`);
        debugger;
        initRvizApp(app, palette, launcher, restorer, appConfig);
    }
}
;
function initRvizApp(app, palette, launcher, restorer, appConfig) {
    // Declare widget variables
    let widget;
    let url = `${BASE_URL}${appConfig.url}?baseurl=${BASE_URL}`;
    // Add an application command
    const command = `rviz:${appConfig.name}`;
    const icon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.LabIcon({
        name: `launcher:${appConfig.name}`,
        svgstr: appConfig.iconStr || _style_Ros_logo_svg__WEBPACK_IMPORTED_MODULE_5__["default"],
    });
    app.commands.addCommand(command, {
        caption: appConfig.title,
        label: (args) => (args['isPalette'] ? `Open ${appConfig.title}` : appConfig.title),
        icon: (args) => (args['isPalette'] ? '' : icon),
        execute: () => {
            if (!widget || widget.isDisposed) {
                const content = new _iframe__WEBPACK_IMPORTED_MODULE_6__["default"](url);
                widget = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.MainAreaWidget({ content });
                widget.id = `rviz-${appConfig.name}`;
                widget.title.label = appConfig.title;
                widget.title.closable = true;
            }
            if (!tracker.has(widget)) {
                // Track the state of the widget for later restoration
                tracker.add(widget);
            }
            if (!widget.isAttached) {
                // Attach the widget to the main work area if it's not there
                let mode = appConfig.mode;
                app.shell.add(widget, 'main', { mode });
            }
            // Activate the widget
            app.shell.activateById(widget.id);
        }
    });
    // Add the command to the palette.
    palette.addItem({ command, category: 'Robotics' });
    if (launcher) {
        launcher.add({
            command,
            category: 'Robotics',
        });
    }
    // Track and restore the widget state
    let tracker = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.WidgetTracker({
        namespace: `rviz-${appConfig.name}`
    });
    if (restorer) {
        restorer.restore(tracker, {
            command,
            name: () => `rviz-${appConfig.name}`
        });
    }
}
const plugin = {
    id: 'jupyterlab_rviz',
    autoStart: true,
    requires: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ICommandPalette],
    optional: [_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_2__.ILauncher, _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__.ILayoutRestorer],
    activate: activate
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.b19d541a65e9ca4923b9.js.map