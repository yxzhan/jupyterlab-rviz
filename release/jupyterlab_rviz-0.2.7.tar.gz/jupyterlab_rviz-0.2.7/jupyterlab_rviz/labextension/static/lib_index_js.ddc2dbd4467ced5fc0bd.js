"use strict";
(self["webpackChunkjupyterlab_rviz"] = self["webpackChunkjupyterlab_rviz"] || []).push([["lib_index_js"],{

/***/ "./node_modules/css-loader/dist/cjs.js!./style/base.css":
/*!**************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/base.css ***!
  \**************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "/*\n    See the JupyterLab Developer Guide for useful CSS Patterns:\n\n    https://jupyterlab.readthedocs.io/en/stable/developer/css.html\n*/\n", "",{"version":3,"sources":["webpack://./style/base.css"],"names":[],"mappings":"AAAA;;;;CAIC","sourcesContent":["/*\n    See the JupyterLab Developer Guide for useful CSS Patterns:\n\n    https://jupyterlab.readthedocs.io/en/stable/developer/css.html\n*/\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./style/index.css":
/*!***************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/index.css ***!
  \***************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! -!../node_modules/css-loader/dist/cjs.js!./base.css */ "./node_modules/css-loader/dist/cjs.js!./style/base.css");
// Imports



var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_2__["default"]);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "div.iframe-widget {\n  height:100%;\n  width:100%;\n}\n\ndiv.iframe-widget iframe{\n  height:100%;\n  width:100%;\n}\n\n/*\nfrom: https://github.com/ian-r-rose/jupyterlab/blob/d7ec6ec271fcbeed2a0f5b1ed652a4802a430496/packages/htmlviewer/style/index.css;\nWhen drag events occur, `p-mod-override-cursor` is added to the body.\nBecause iframes steal all cursor events, the following two rules are necessary\nto suppress pointer events while resize drags are occuring. There may be a\nbetter solution to this problem.\n*/\nbody.p-mod-override-cursor div.iframe-widget {\nposition: relative;\npointer-events: none;\n\n}\n\nbody.p-mod-override-cursor div.iframe-widget:before {\ncontent: '';\nposition: absolute;\ntop: 0;\nleft: 0;\nright: 0;\nbottom: 0;\nbackground: transparent;\n}", "",{"version":3,"sources":["webpack://./style/index.css"],"names":[],"mappings":"AAEA;EACE,WAAW;EACX,UAAU;AACZ;;AAEA;EACE,WAAW;EACX,UAAU;AACZ;;AAEA;;;;;;CAMC;AACD;AACA,kBAAkB;AAClB,oBAAoB;;AAEpB;;AAEA;AACA,WAAW;AACX,kBAAkB;AAClB,MAAM;AACN,OAAO;AACP,QAAQ;AACR,SAAS;AACT,uBAAuB;AACvB","sourcesContent":["@import url('base.css');\n\ndiv.iframe-widget {\n  height:100%;\n  width:100%;\n}\n\ndiv.iframe-widget iframe{\n  height:100%;\n  width:100%;\n}\n\n/*\nfrom: https://github.com/ian-r-rose/jupyterlab/blob/d7ec6ec271fcbeed2a0f5b1ed652a4802a430496/packages/htmlviewer/style/index.css;\nWhen drag events occur, `p-mod-override-cursor` is added to the body.\nBecause iframes steal all cursor events, the following two rules are necessary\nto suppress pointer events while resize drags are occuring. There may be a\nbetter solution to this problem.\n*/\nbody.p-mod-override-cursor div.iframe-widget {\nposition: relative;\npointer-events: none;\n\n}\n\nbody.p-mod-override-cursor div.iframe-widget:before {\ncontent: '';\nposition: absolute;\ntop: 0;\nleft: 0;\nright: 0;\nbottom: 0;\nbackground: transparent;\n}"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./style/R.svg":
/*!*********************!*\
  !*** ./style/R.svg ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<svg width=\"22\" height=\"30\" viewBox=\"0 0 22 30\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path d=\"M0.522727 30V0.90909H10.3523C12.625 0.90909 14.4905 1.29735 15.9489 2.07386C17.4072 2.84091 18.4867 3.89678 19.1875 5.24148C19.8883 6.58617 20.2386 8.11553 20.2386 9.82955C20.2386 11.5436 19.8883 13.0634 19.1875 14.3892C18.4867 15.715 17.4119 16.7566 15.9631 17.5142C14.5142 18.2623 12.6629 18.6364 10.4091 18.6364H2.45455V15.4545H10.2955C11.8485 15.4545 13.0985 15.2273 14.0455 14.7727C15.0019 14.3182 15.6932 13.6742 16.1193 12.8409C16.5549 11.9981 16.7727 10.9943 16.7727 9.82955C16.7727 8.66477 16.5549 7.64678 16.1193 6.77557C15.6837 5.90436 14.9877 5.23201 14.0312 4.75852C13.0748 4.27557 11.8106 4.03409 10.2386 4.03409H4.04545V30H0.522727ZM14.2159 16.9318L21.375 30H17.2841L10.2386 16.9318H14.2159Z\" fill=\"#ADACEC\"/>\n</svg>\n");

/***/ }),

/***/ "./lib/iframe.js":
/*!***********************!*\
  !*** ./lib/iframe.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _style_index_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../style/index.css */ "./style/index.css");


class IFrameWidget extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__.Widget {
    /**
    * Construct a new IFrameWidget widget.
    */
    constructor(url) {
        super();
        console.log(`Open url:\n${url}`);
        const div = document.createElement("div");
        div.classList.add("iframe-widget");
        let iframe = document.createElement("iframe");
        iframe = document.createElement('iframe');
        iframe.src = url;
        iframe.style.width = '100%';
        iframe.style.height = '100%';
        div.appendChild(iframe);
        this.node.appendChild(div);
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (IFrameWidget);


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/application */ "webpack/sharing/consume/default/@jupyterlab/application");
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/launcher */ "webpack/sharing/consume/default/@jupyterlab/launcher");
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _iframe__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./iframe */ "./lib/iframe.js");
/* harmony import */ var _style_R_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../style/R.svg */ "./style/R.svg");







const BASE_URL = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_4__.PageConfig.getBaseUrl();
/**
 * Initialization data for the jupyterlab_rviz extension.
 */
async function activate(app, palette, launcher, restorer) {
    console.log('JupyterLab extension jupyterlab_rviz is activated!');
    let response = await fetch(`${BASE_URL}proxy/8001/rvizweb/webapps/app.json`);
    if (!response.ok) {
        const data = await response.json();
        if (data.error) {
            console.log(data.error);
        }
        return;
    }
    const RvizApps = await response.json();
    for (let appConfig of RvizApps) {
        response = await fetch(`${BASE_URL}${appConfig.icon}`);
        if (response.ok) {
            appConfig.iconStr = await response.text();
        }
        let command = initRvizApp(app, palette, launcher, restorer, appConfig, RvizApps.indexOf(appConfig));
        if (appConfig.start) {
            app.commands.execute(command, { origin: 'init' }).catch((reason) => {
                console.error(`An error occurred during the execution of ${command}.\n${reason}`);
            });
        }
    }
}
;
function initRvizApp(app, palette, launcher, restorer, appConfig, rank) {
    // Declare widget variables
    let widget;
    let url = `${BASE_URL}${appConfig.url}?baseurl=${BASE_URL}`;
    // Hard code for webviz url parameter
    // Have not figured out a better solution :(
    if (appConfig.name === 'webviz') {
        let wsUrl = new URL(BASE_URL);
        wsUrl.protocol = wsUrl.protocol === 'https:' ? 'wss:' : 'ws';
        url = `${BASE_URL}${appConfig.url}?rosbridge-websocket-url=${wsUrl.href}proxy/9090`;
    }
    // Add an application command
    const closable = appConfig.closable !== undefined ? Boolean(appConfig.closable) : true;
    const command = `rviz:${appConfig.name}`;
    const icon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.LabIcon({
        name: `launcher:${appConfig.name}`,
        svgstr: appConfig.iconStr || _style_R_svg__WEBPACK_IMPORTED_MODULE_5__["default"],
    });
    app.commands.addCommand(command, {
        caption: appConfig.title,
        label: (args) => (args['isPalette'] ? `Open ${appConfig.title}` : appConfig.title),
        icon: (args) => (args['isPalette'] ? '' : icon),
        execute: () => {
            if (!widget || widget.isDisposed) {
                const content = new _iframe__WEBPACK_IMPORTED_MODULE_6__["default"](url);
                widget = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.MainAreaWidget({ content });
                widget.id = `rviz-${appConfig.name}`;
                widget.title.label = appConfig.title;
                widget.title.closable = closable;
            }
            if (!tracker.has(widget)) {
                // Track the state of the widget for later restoration
                tracker.add(widget);
            }
            if (!widget.isAttached) {
                // Attach the widget to the main work area if it's not there
                let mode = appConfig.mode;
                app.shell.add(widget, 'main', { mode });
            }
            // Activate the widget
            app.shell.activateById(widget.id);
        }
    });
    // Add the command to the palette.
    palette.addItem({ command, category: 'Robotics' });
    if (launcher) {
        launcher.add({
            command,
            category: 'Robotics',
            rank
        });
    }
    // Track and restore the widget state
    let tracker = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.WidgetTracker({
        namespace: `rviz-${appConfig.name}`
    });
    if (restorer) {
        restorer.restore(tracker, {
            command,
            name: () => `rviz-${appConfig.name}`
        });
    }
    return command;
}
const plugin = {
    id: 'jupyterlab_rviz',
    autoStart: true,
    requires: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ICommandPalette],
    optional: [_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_2__.ILauncher, _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__.ILayoutRestorer],
    activate: activate
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ }),

/***/ "./style/index.css":
/*!*************************!*\
  !*** ./style/index.css ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../node_modules/css-loader/dist/cjs.js!./index.css */ "./node_modules/css-loader/dist/cjs.js!./style/index.css");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ })

}]);
//# sourceMappingURL=lib_index_js.ddc2dbd4467ced5fc0bd.js.map